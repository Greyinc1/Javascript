let password1El = document.getElementById("password1-el")
let password2El = document.getElementById("password2-el")
let generatePasswordBtn = document.getElementById("generate-password-btn")
let coptTextBtn = document.getElementById("copy-text-btn")
let copyTextBtn2 = document.getElementById("copt-text-btn2")

const characters = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9","~","`","!","@","#","$","%","^","&","*","(",")","_","-","+","=","{","[","}","]",",","|",":",";","<",">",".","?",
"/"];

let passwordLength = 14

function randomCharacter(){
    let password1 = Math.floor(Math.random() * characters.length)
    let password2 = Math.floor(Math.random() * characters.length)
    password1El.textContent += characters[password1]
    password2El.textContent += characters[password2] 
}

function generatePassword(){
    let randomPassword = ""
        for (let i = 0; i < passwordLength; i++) {
        randomPassword += randomCharacter()         
        }
        return randomPassword
}

function resetPassword(){
    password1El.textContent = ""
    password2El.textContent = ""
}
        
//const password1 = generatePassword()
//const password2 = generatePassword()

//console.log(password1)
//console.log(password2)








